<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
        $('input[type="radio"]').click(function(){
            if($(this).attr("value")=="yes"){
                $(".box").hide();
                $(".bS01").show();
            }
        });
    });
</script>