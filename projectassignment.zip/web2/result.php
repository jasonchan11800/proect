<html>
<head>	
	<title>Booking info</title>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<link href="layout.css" rel="stylesheet" type="text/css">
	<link href="style.css" rel="stylesheet" type="text/css">
	<link href="print.css" rel="stylesheet" type="text/css" media="print">
	
	
	<script>
		function printPage() {
		window.print();
		}
	</script>
</head>	
<body>
   <header>
   	<a href="index.html" ><img id="logo" src="images/BTTY.png" alt=""/></a>
   </header>
	<br>			
		<div class= "gn">
			<h1>&nbsp&nbsp Back To Tsing Yi Limited</h1>
		</div>	
	<br>
	<h1>Your Ticket Information</h1>
<?php
	$total= 0;
			$cookie = $_COOKIE["ID"];
			$db = new PDO("mysql:host=localhost;dbname=projectAssignment", "root", "");
			$sql = "select * from booking where ticket_No = '$cookie'";
			$result = $db->query($sql);
			echo '<table border="1" style="min-width:700px; max-width:700px;" align="center">';
				$row = $result->fetch(PDO::FETCH_ASSOC);
				foreach ($row as $key => $value) {
					if($key == 'ticket_No'){
						echo "<tr>";
						echo "<th>Ticket No:</th>";
						echo "<td>$value</td>";
						echo "</tr>";
					}
					else if($key == 'name'){
						echo "<tr>";
						echo "<th>Name:</th>"; 
						echo "<td>$value</td>";
						echo "</tr>";
					}
					else if($key == "District"){
						echo "<tr>";
						echo "<th>District:</th>";
						echo "<td>$value</td>";
						echo "</tr>";
					}
					else if($key == "ticket_type"){
						echo "<tr>";
						echo "<th>Ticket Type:</th>";
						echo "<td>$value</td>";
						if ($value == "Regular")
							$total +=100;
						else if ($value == "Student")
							$total +=50;
						else 
							$total +=20;
						echo "</tr>";
					}
					else if($key == "parking"){
						echo "<tr>";
						echo "<th>Parking:</th>";
						if ($value =="Yes"){
							$total += 20;
						}
						echo "<td>$value</td>";
						echo "</tr>";
					}					
					else if($key == "std_No"){
						if ($value == "")
							continue;
						else {
							echo "<tr>";
							echo "<th>Student No.:</th>";
							echo "<td>$value</td>";
							echo "</tr>";
						}
					}
				}
						echo "<tr>";
						echo "<th>Total Price:</th>";
						echo "<td>\$ $total</td>";
						echo "</tr>";
				echo "</table>";
			
			echo '<input type="button" value="Print this page" onclick="printPage()" />';
				

?>
	<h3 id="no">*Please Print this page and bring your ID card and Student ID card (if necessary) to confirm your identity. </h3>
</body>
</html>