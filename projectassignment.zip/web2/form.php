<html>
<head>
	<title>Reserve</title>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<link href="layout.css" rel="stylesheet" type="text/css">
	<link href="style.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function(){
        $('input[name="ticket_type"]').click(function(){
            if($(this).attr("value")=="Student"){
                $(".box").hide();
                $(".bS01").show();
            }
			
			else{
                $(".box").hide();
                $(".bS02").show();
            }
        });
    });
	</script>
</head>
<body>
	<?php
	$message ="";
	$db = new PDO("mysql:host=localhost;dbname=projectAssignment", "root", "");
	$sql = "select count(ticket_No) from booking";	
		$result = $db->query($sql);
		$count = $result->fetchColumn();
		if ($count >= 120){
			$message = "Sorry! We are Fully Booked!";
			header("Refresh:0; url= index.html");
			echo "<script type='text/javascript'>alert('$message');</script>";}
	?>
   <header>
   	<a href="index.html" ><img id="logo" src="images/BTTY.png" alt=""/></a>		
		<br>			
		<div class= "gn">
			<h1>&nbsp&nbsp Back To Tsing Yi Limited</h1>
		</div>	
		<br>
		<br>
   </header>
	<form id="survry" method="POST" action="form.php">
		<fieldset>
			<legend>Reserve form</legend>
				<div class="formRow">
					<label for="name">Name:</label>
				<div class="col-75">
					<input name="name" id="name" type="text" class="form-control" required>
				</div>
				</div>
					
				<div class="formRow">
					<label for="District">District:</label>
				<div class="col-75">	
					<select name="District" id="District" required>
						<option value="" Disabled selected>Select your District</option>
						<option disabled>-----New Territories-----</option>
						<option value="Yuen Long">Yuen Long</option>
						<option value="Tuen Mun">Tuen Mun</option>
						<option value="Tsuen Wan">Tsuen Wan</option>
						<option value="Tai Po">Tai Po</option>
						<option value="Sha Tin">Sha Tin</option>
						<option value="Sai Kung">Sai Kung</option>
						<option value="North">North</option>
						<option value="Kwai Tsing">Kwai Tsing</option>
						<option value="Island">Island</option>
						<option disabled>-----Kowloon-----</option>
						<option value="Kowloon City">Kowloon City</option>
						<option value="Kwun Tong">Kwun Tong</option>
						<option value="Sham Shui Po">Sham Shui Po</option>
						<option value="Wong Tai Sin">Wong Tai Sin</option>
						<option value="Yau Tsim Mong">Yau Tsim Mong</option>
						<option disabled>-----Hong Kong Island-----</option>
						<option value="Central and Westerm">Central and Westerm</option>
						<option value="Eastern">Eastern</option>
						<option value="Southern">Southern</option>
						<option value="Wan Chai">Wan Chai</option>
					</select>				
				</div>
				</div>	
				<div class="formRow">
					<p>Ticket Type:<br>
					<label for="Regular" class="container">Regular - $100
						<input name="ticket_type" id="Regular" type="radio" class="form-control" value="Regular" checked>
						<span class="checkmark"></span></label>
					<label for="Student" class="container">Student - $50
						<input name="ticket_type" id="Student" type="radio" class="form-control" value="Student">
						<span class="checkmark"></span></label>
					<label for="Retiree" class="container">Retiree - $20
						<input name="ticket_type" id="Retiree" type="radio" class="form-control" value="Retiree">
						<span class="checkmark"></span></label>
										
				<div class="col-75"><div class="bS01 box bBW" style="display:none;">
							<br><p>Student ID:
						<input name="std_No" id="name" type="text" class="form-control">
							<p>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp *Please show your student ID Card when you get in.
				</div></div>
				</div>
				<p>Parking Ticket:<br>
				<?php
					$sql = 'select count(*) from booking where parking="Yes"';	
					$result = $db->query($sql);
					$count = $result->fetchColumn();
					if ($count >= 100) {
						echo "<br>";
						echo '<font color="#FF0004">Parking space is FULLED!!</font>';
						echo '<input name="parking" id="No" type="hidden" class="form-control" value="No" checked>';}
					else {
					echo '<label for="Yes" class="container">Yes (+$20)';	
						echo '<input name="parking" id="Yes" type="radio" class="form-control" value="Yes">';
						echo '<span class="checkmark"></span></label>';
					echo '<label for="No" class="container">No';
						echo '<input name="parking" id="No" type="radio" class="form-control" value="No" checked>';
						echo '<span class="checkmark"></span></label>';
					}
					
				?>
						
			<br><br>
			
			<input type="submit" name="submit" value="Submit" >
			
			
			
	<?php 					
		$name ="";
		$District ="";
		$ticket_type ="";
		$std_No ="";
		$parking =0;
		
		$name_error = false;
		$type_error = false;
		$District_error = false;
		$parking_error = false;
		$ticketNo_error = false;
		
		if(isset($_POST["submit"]))	{
			
			
			
		if (isset($_POST["name"]) && isset($_POST["District"]) && isset($_POST["ticket_type"]) && isset($_POST["parking"])) {
			$name = $_POST["name"];
			$District = $_POST["District"];
			if ($District == "") 
				$District_error = true;
			$ticket_type = $_POST["ticket_type"];
			$parking = $_POST["parking"];
			if ($_POST["ticket_type"] == "Student"){
				if (isset($_POST["std_No"]))
					$std_No = $_POST["std_No"];
				if($std_No == "")
					$type_error = true;
		}}
			
		$sql = 'select count(*) from booking where parking="Yes"';	
			$result = $db->query($sql);
			$count = $result->fetchColumn();
			if ($count >= 100) {	
				$message = "Parking space is fulled!! Sorry.";
				echo "<script type='text/javascript'>alert('$message');</script>";
				$parking_error = true;
			} else {$parking_error = false;}
			
		$sql = 'select count(ticket_No) from booking';	
			$result = $db->query($sql);
			$count = $result->fetchColumn();
			if ($count >= 120) {	
				$message = "Sorry! We are Fully Booked!";
				
				header("Refresh:0; url= index.html");
				echo "<script type='text/javascript'>alert('$message');</script>";
				$ticketNo_error = true;
			} else {$ticketNo_error = false;}
		
					
		if ($parking_error == false && $ticketNo_error == false){	
		if ($name_error == false && $type_error == false && $District_error == false) {
		$sql = "insert into booking (name, District, ticket_type, std_No, parking) values (:name, :District, :ticket_type, :std_No, :parking)";
		$statement = $db -> prepare($sql);
		$result = $statement -> execute(array(
			":name" => $name,
			":District" => $District ,
			":ticket_type" => $ticket_type ,
			":std_No" => $std_No ,
			":parking" => $parking
			));	
			
			$last_id = $db -> lastInsertId();
			setcookie("ID",$last_id);
			header("Refresh:0; url= result.php");
						
		} 
			else { 
				$message = "Please fill in all column!!";
				echo "<script type='text/javascript'>alert('$message');</script>";
			}}
		}
					
	?>
</body>
</html>