<html>
<head>	
	<title>Check</title>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<link href="layout.css" rel="stylesheet" type="text/css">
	<link href="style.css" rel="stylesheet" type="text/css">
	<link href="print.css" rel="stylesheet" type="text/css" media="print">
	
	<script>
		function printPage() {
		window.print();
		}
	</script>
</head>
<body class="check">
	<header>
   	<a href="index.html" ><img id="logo" src="images/BTTY.png" alt=""/></a>
  	</header>
	<br>			
	<div class= "gn">
		<h1>&nbsp&nbsp Back To Tsing Yi Limited</h1>
	</div>	
	<br>
	<div class="check">
	<h1>Check Your Ticket</h1>
	
	<form id="survry" method="POST" action="check.php">
		<fieldset>
			<legend>Checking</legend>
				<div class="formRow">
					<label for="ID">Ticket Number:</label>
				<div class="col-75">
					<input name="ID" id="ID" type="text" class="form-control" required>
				</div>
				</div>
			
				<div class="formRow">
					<label for="name">Name:</label>
				<div class="col-75">
					<input name="name" id="name" type="text" class="form-control" required>
				</div>
				</div>
			<input type="submit" name="submit" value="Submit" >
				</fieldset>
	</form>
	</div>	
	<div class="checkform">
	<?php
		$db = new PDO("mysql:host=localhost;dbname=projectAssignment", "root", "");

	
		if (isset ($_POST["submit"])){
			$last_id = $_POST["ID"];
			$name = $_POST["name"];	
			
	
	
		$sql = "select * from booking where name= :name and ticket_No = :last_id";	
		$statement = $db -> prepare($sql);
			$result = $statement -> execute(array(
			":name" => $name,
			":last_id" => $last_id
			));		

		if ($result == true){
			$sql = "select * from booking where name= '$name' and ticket_No = '$last_id'";
				$result = $db->query($sql);
				$row = $result->fetch(PDO::FETCH_ASSOC);
				if ($row == true){	
				echo '<h1> Your Ticket Information</h1>';
				echo '<table border="1" style="min-width:700px; max-width:700px;" align="center">';
					$total= 0;	
				foreach ($row as $key => $value) {
					if($key == 'ticket_No'){
						echo "<tr>";
						echo "<th>Ticket No:</th>";
						echo "<td>$value</td>";
						echo "</tr>";	}
					else if($key == 'name'){
						echo "<tr>";
						echo "<th>Name:</th>"; 
						echo "<td>$value</td>";
						echo "</tr>";	}
					else if($key == "District"){
						echo "<tr>";
						echo "<th>District:</th>";
						echo "<td>$value</td>";
						echo "</tr>";	}
					else if($key == "ticket_type"){
						echo "<tr>";
						echo "<th>Ticket Type:</th>";
						echo "<td>$value</td>";
						if ($value == "Regular")
							$total +=100;
						else if ($value == "Student")
							$total +=50;
						else 
							$total +=20;
						echo "</tr>";	}
					else if($key == "parking"){
						echo "<tr>";
						echo "<th>Parking:</th>";
						if ($value =="Yes"){
							$total += 20;	}
						echo "<td>$value</td>";
						echo "</tr>";	}					
					else if($key == "std_No"){
						if ($value == "")
							continue;
						else {
							echo "<tr>";
							echo "<th>Student No.:</th>";
							echo "<td>$value</td>";
							echo "</tr>";	}	} 		
					
			}
					echo "<tr>";
					echo "<th>Total Price:</th>";
					echo "<td>\$ $total</td>";
					echo "</tr>";
					echo "</table>";
									
			echo '<input type="button" value="Print this page" onclick="printPage()" />';}
		
			else 
				echo '<h1 style="color:red; text-align:center" >*No result*</h1>';
		}}
	?>
</div>
	
</body>
</html>